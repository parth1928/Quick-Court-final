"use client";

import DashboardPage from '@/components/charts/DashboardPage';

export default function AnalyticsPage() {
  return <DashboardPage />;
}
